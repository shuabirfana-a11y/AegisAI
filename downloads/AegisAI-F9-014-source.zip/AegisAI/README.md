# AegisAI 项目源码

参赛组号：F9-014。中国电子杯第三届高校 ICT 产教融合创新大赛，赛题九。

项目名称：智能体驱动的 AI 安全知识情报系统设计与实现。

## 先看哪里

1. 直接查看在线静态演示：https://shuabirfana-a11y.github.io/AegisAI/
2. 本机运行：阅读根目录 QUICKSTART_WINDOWS.md。它包含数据库、模型、迁移和前后端启动步骤。
3. 查看实现：后端在 backend/app/，前端在 frontend/，数据库迁移在 backend/alembic/。

## 系统内容

- 情报监测：多源采集、标准化、去重及原文记录。
- 情报富化：漏洞属性、产品与包身份、维护分支、影响范围及补丁候选关联。
- 情报问答：受约束任务规划、取证核验、登记资产版本分析和带证据的结构化回答。

核心实现入口：

|内容|目录或文件|
|---|---|
|HTTP 接口与应用入口|backend/app/main.py|
|调查任务规划与约束|backend/app/agents/investigation/|
|证据与声明核验|backend/app/enrichment/|
|任务执行与结果交付|backend/app/orchestration/|
|Integration Gate|backend/app/integration/|
|前端页面和代理|frontend/public/、frontend/server.mjs|
|数据库迁移|backend/alembic/|
|Python 和前端依赖|backend/requirements.txt、frontend/package.json、frontend/package-lock.json|
|环境字段示例|backend/.env.example|
|来源与第三方许可|DATA_SOURCES.md、THIRD_PARTY.md、licenses/|

## 运行准备

需要 Windows PowerShell 7、Python 3.12、Node.js 22+、PostgreSQL 17，以及实际可用的模型服务。数据库、模型权重及 API 凭证由运行者自行准备，源码不包含私有数据库或密钥。建议解压到 C:/AegisAI 等短路径。

完整步骤以 QUICKSTART_WINDOWS.md 为准：安装依赖，配置专用数据库和模型，执行迁移，启动后端，再启动前端。默认后端 http://127.0.0.1:8000，前端 http://127.0.0.1:8769/assistant。端口及环境应按启动说明设置。

## 版本与演示范围

本包程序文件来自公开交付源码：后端基线 4fddc5c40eb8231cb6e7a55f7f479035502b4ea9；队友前端更新 437cb844830116f638f6aaed66680e8de367e8c2；公开整合提交 641295086e2166ef7967d73a01abc480cc2132e4。SOURCE_VERSION.json 保留原版本标识。

本次仅整理文档入口，未修改后端、前端、迁移、测试或模型配置。根目录历史阶段报告未纳入此精简包，完整记录仍保留在本地及既有项目归档中。技术报告、技术讲解和操作视频作为单独材料定稿后提供，本包不夹带旧稿。

GitHub Pages 展示已有真实案例和证据，不调用模型或发起新调查。监测看板等页面包含明确的演示数据。需要现场调查时，应按启动说明运行完整系统并选择真实 API。

当前版本适合本地研究和演示。Windows Worker 组合执行仍存在未解决问题；并发、取消、超时、冷启动及整体风险分级的可靠性尚需进一步验证。保留未知、冲突和人工复核状态。

## 补充资料

tests/ 与 backend/tests/（若存在）提供对应测试；evaluation/ 保留评测程序及数据契约；docs/ 提供接口和架构说明。评委可从本文件和快速启动开始，无需逐一阅读历史研发材料。部分历史文档指向开发机归档，不能替代本包的启动说明。
